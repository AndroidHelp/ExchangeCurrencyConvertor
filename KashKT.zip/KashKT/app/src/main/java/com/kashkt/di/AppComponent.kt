package com.kashkt.di

class AppComponent {
}